#!/bin/bash
source /etc/profile.d/my_env.sh
/opt/module/flume/bin/flume-ng agent --conf conf/ --name a2 --conf-file /opt/module/flume/job/flume-file-hdfs.conf

