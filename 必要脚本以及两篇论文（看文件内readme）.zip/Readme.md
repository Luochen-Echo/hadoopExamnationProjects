### 不要修改文件名称否则自己去修改后端相应接口的参数
#### flume_script.sh和kill_flume_script.sh以及wordcount_script.sh放在家目录下举个例子~/或者/home/roger(我自己的机器)
#### flume-file-hdfs.conf放在/opt/flume/job下面（用来监测系统日志文件/var/log/messages）第三个功能无法实现所以我改成了监测系统日志文件
![](https://raw.githubusercontent.com/martine-stdo/my_images/master/20230606212208.png)
**需要修改的部分如上图所示：
根据自己的实际情况修改如你使用的的数据库
用户名以及密码
hadoop的相关配置**
![](https://raw.githubusercontent.com/martine-stdo/my_images/master/20230606212500.png)
表的列族必须和上图保持一致，
id设置为主键，并且是**自增id int(auto increment) **