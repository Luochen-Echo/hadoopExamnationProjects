#!/bin/bash
source /etc/profile.d/my_env.sh
kill $(ps -ef | grep "[f]lume" | awk '{print $2}')
