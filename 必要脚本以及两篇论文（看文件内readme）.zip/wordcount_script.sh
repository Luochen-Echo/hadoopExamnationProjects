#!/bin/bash
source /etc/profile.d/my_env.sh
hadoop jar /opt/module/wordcount.jar WordCount

